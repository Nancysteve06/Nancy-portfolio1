import { useEffect } from "react";
import Navbar from "@/components/navbar";
import HeroSection from "@/components/hero-section";
import AboutSection from "@/components/about-section";
import PortfolioSection from "@/components/portfolio-section";
import SkillsSection from "@/components/skills-section";
import UniqueValueSection from "@/components/unique-value-section";
import ContactSection from "@/components/contact-section";
import Footer from "@/components/footer";
import { setupFadeAnimations } from "@/lib/animated-elements";

export default function Home() {
  useEffect(() => {
    // Setup fade-in animations on scroll
    setupFadeAnimations();
  }, []);

  return (
    <div className="min-h-screen">
      <Navbar />
      <HeroSection />
      <main className="max-w-5xl mx-auto px-6 py-16 bg-background">
        <AboutSection />
        <PortfolioSection />
        <SkillsSection />
        <UniqueValueSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}
