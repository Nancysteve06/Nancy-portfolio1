export interface ProjectType {
  title: string;
  description: string[];
  image: {
    src: string;
    alt: string;
  };
  skills: string[];
}

export const projects: ProjectType[] = [
  {
    title: "Elegant E-Commerce Store (Magento)",
    description: [
      "Custom product filtering and secure checkout integration",
      "22% sales conversion boost within one month",
      "Mobile-first design with intuitive navigation"
    ],
    image: {
      src: "https://images.unsplash.com/photo-1472851294608-062f824d29cc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
      alt: "E-commerce store design"
    },
    skills: ["Magento", "CSS", "JavaScript"]
  },
  {
    title: "Digital Portfolio Website (Duda)",
    description: [
      "Minimalist layout with strong structural coherence",
      "Multilingual, SEO-optimised, and content-rich",
      "Custom scripting for interactive elements"
    ],
    image: {
      src: "https://images.unsplash.com/photo-1517433367423-c7e5b0f35086?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
      alt: "Digital portfolio website"
    },
    skills: ["Duda", "HTML", "JavaScript"]
  },
  {
    title: "SEO Revamp for Small Business",
    description: [
      "65% organic traffic growth in under 90 days",
      "First-page ranking for key niche terms",
      "Backlink strategy and metadata overhaul"
    ],
    image: {
      src: "https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
      alt: "SEO strategy dashboard"
    },
    skills: ["SEO", "Analytics", "Content Strategy"]
  },
  {
    title: "VA Dashboard & Workflow System",
    description: [
      "Real-time client collaboration environment",
      "30% reduction in client administrative workload",
      "Automated task templates and dashboards"
    ],
    image: {
      src: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80",
      alt: "VA Dashboard interface"
    },
    skills: ["Workflow", "Automation", "Dashboard Design"]
  }
];
