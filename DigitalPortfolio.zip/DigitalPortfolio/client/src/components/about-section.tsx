import FadeIn from "@/components/fade-in";

export default function AboutSection() {
  return (
    <section id="about" className="mb-24">
      <FadeIn>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-semibold text-primary mb-2">About Me</h2>
          <div className="section-divider"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          <div className="md:col-span-7">
            <p className="leading-relaxed text-secondary mb-6">
              I'm Nancy Steve—a multilingual digital artisan with a deep appreciation for refined design, structured logic, and seamless user experiences. With a foundation of remote-first internships and global certifications, I build digital experiences that elegantly marry purpose with polish.
            </p>
            <p className="leading-relaxed text-secondary">
              Whether translating brand stories into aesthetic interfaces or managing client operations with gentle precision, my mission remains simple: to deliver exquisite digital results with grace, professionalism, and heart.
            </p>
          </div>
          <div className="md:col-span-5">
            <img 
              src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&h=400&q=80"
              alt="Web development workspace"
              className="w-full h-auto rounded-lg shadow-md"
            />
          </div>
        </div>
      </FadeIn>
    </section>
  );
}
