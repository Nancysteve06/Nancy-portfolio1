import { Button } from "@/components/ui/button";
import FadeIn from "@/components/fade-in";

export default function HeroSection() {
  return (
    <header className="relative pt-32 pb-20 md:pt-40 md:pb-32 px-6 bg-white border-b border-gray-200">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-2/3 text-center md:text-left md:pr-12">
            <FadeIn delay={0}>
              <h1 className="text-4xl md:text-5xl font-bold tracking-wide mb-4 text-primary">Nancy Steve</h1>
            </FadeIn>
            
            <FadeIn delay={0.1}>
              <div className="section-divider my-6 mx-auto md:mx-0"></div>
            </FadeIn>
            
            <FadeIn delay={0.2}>
              <p className="italic text-lg text-secondary mb-4">
                Bilingual Web Developer | E-commerce Specialist | Certified Virtual Assistant
              </p>
            </FadeIn>
            
            <FadeIn delay={0.3}>
              <p className="text-accent mb-8">
                Elegance in code. Precision in support. Excellence in every click.
              </p>
            </FadeIn>
            
            <FadeIn delay={0.4}>
              <div className="flex space-x-4 justify-center md:justify-start">
                <Button asChild variant="default" className="px-6 py-3 bg-primary text-white hover:bg-primary/90 h-auto">
                  <a href="#portfolio">View My Work</a>
                </Button>
                <Button asChild variant="outline" className="px-6 py-3 border-primary text-primary hover:bg-primary hover:text-white h-auto">
                  <a href="#contact">Contact Me</a>
                </Button>
              </div>
            </FadeIn>
          </div>
          
          <div className="md:w-1/3 mt-10 md:mt-0">
            <FadeIn delay={0.5}>
              <img
                src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&h=500&q=80"
                alt="Nancy Steve - Professional Headshot"
                className="profile-img mx-auto shadow-lg w-64 h-64 object-cover"
              />
            </FadeIn>
          </div>
        </div>
      </div>
    </header>
  );
}
