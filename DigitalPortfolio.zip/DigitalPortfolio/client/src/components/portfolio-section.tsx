import { projects } from "@/lib/portfolio-data";
import ProjectCard from "@/components/project-card";
import FadeIn from "@/components/fade-in";

export default function PortfolioSection() {
  return (
    <section id="portfolio" className="mb-24">
      <FadeIn>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-semibold text-primary mb-2">Highlighted Works</h2>
          <div className="section-divider mb-6"></div>
          <p className="text-accent max-w-2xl mx-auto">
            A selection of projects that showcase my expertise and approach to digital solutions.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <ProjectCard key={index} project={project} />
          ))}
        </div>
      </FadeIn>
    </section>
  );
}
