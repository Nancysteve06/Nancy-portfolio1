import FadeIn from "@/components/fade-in";
import { Code, ShoppingCart, LineChart, Laptop } from "lucide-react";

export default function SkillsSection() {
  return (
    <section id="skills" className="mb-24">
      <FadeIn>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-semibold text-primary mb-2">Technical Tools</h2>
          <div className="section-divider mb-6"></div>
          <p className="text-accent max-w-2xl mx-auto">
            The technologies and tools I use to bring digital ideas to life.
          </p>
        </div>
        
        <div className="bg-white p-8 rounded-lg shadow-md">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <div className="mb-6">
                <h3 className="text-xl font-bold text-primary mb-3 flex items-center">
                  <Code className="mr-3 text-accent h-5 w-5" /> Web Development
                </h3>
                <ul className="list-disc list-inside pl-4 text-secondary space-y-2">
                  <li>Magento, Duda, HTML, CSS, JavaScript, PHP</li>
                  <li>Responsive design and cross-browser compatibility</li>
                  <li>Frontend UI development and optimization</li>
                </ul>
              </div>
              
              <div className="mb-6">
                <h3 className="text-xl font-bold text-primary mb-3 flex items-center">
                  <ShoppingCart className="mr-3 text-accent h-5 w-5" /> E-commerce
                </h3>
                <ul className="list-disc list-inside pl-4 text-secondary space-y-2">
                  <li>WooCommerce, Shopify, payment integration</li>
                  <li>Product catalog management and optimization</li>
                  <li>Checkout flow design and conversion optimization</li>
                </ul>
              </div>
            </div>
            
            <div>
              <div className="mb-6">
                <h3 className="text-xl font-bold text-primary mb-3 flex items-center">
                  <LineChart className="mr-3 text-accent h-5 w-5" /> Analytics & SEO
                </h3>
                <ul className="list-disc list-inside pl-4 text-secondary space-y-2">
                  <li>SEMrush, Google Analytics, Search Console</li>
                  <li>Performance tracking and conversion optimization</li>
                  <li>SEO audits and implementation strategies</li>
                </ul>
              </div>
              
              <div className="mb-6">
                <h3 className="text-xl font-bold text-primary mb-3 flex items-center">
                  <Laptop className="mr-3 text-accent h-5 w-5" /> Office & Remote Work
                </h3>
                <ul className="list-disc list-inside pl-4 text-secondary space-y-2">
                  <li>Microsoft 365, Google Workspace, Trello, Slack</li>
                  <li>Virtual assistance and client communication</li>
                  <li>Project management and team collaboration</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </FadeIn>
    </section>
  );
}
