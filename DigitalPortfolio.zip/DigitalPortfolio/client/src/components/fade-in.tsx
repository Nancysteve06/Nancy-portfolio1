import { ReactNode } from "react";

interface FadeInProps {
  children: ReactNode;
  delay?: number;
  className?: string;
}

export default function FadeIn({ children, delay = 0, className = "" }: FadeInProps) {
  const delayStyle = delay ? { transitionDelay: `${delay}s` } : {};
  
  return (
    <div 
      className={`fade-in ${className}`} 
      style={delayStyle}
    >
      {children}
    </div>
  );
}
