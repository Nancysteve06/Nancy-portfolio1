import { Linkedin, Github, Dribbble } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-white border-t border-gray-200 py-8">
      <div className="max-w-5xl mx-auto px-6 text-center">
        <div className="mb-4">
          <a 
            href="https://www.linkedin.com/in/nancy-steve-913aa8351" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-block text-accent hover:text-primary mx-2 transition-colors"
            aria-label="LinkedIn"
          >
            <Linkedin className="h-5 w-5" />
          </a>
          
          <a 
            href="#" 
            className="inline-block text-accent hover:text-primary mx-2 transition-colors"
            aria-label="GitHub"
          >
            <Github className="h-5 w-5" />
          </a>
          
          <a 
            href="#" 
            className="inline-block text-accent hover:text-primary mx-2 transition-colors"
            aria-label="Dribbble"
          >
            <Dribbble className="h-5 w-5" />
          </a>
        </div>
        
        <p className="text-secondary text-sm">
          &copy; {currentYear} Nancy Steve. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
