import FadeIn from "@/components/fade-in";
import { Languages, Palette, Globe, Award } from "lucide-react";

export default function UniqueValueSection() {
  return (
    <section className="mb-24">
      <FadeIn>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-semibold text-primary mb-2">What Makes Me Different</h2>
          <div className="section-divider mb-6"></div>
        </div>
        
        <div className="bg-white p-8 rounded-lg shadow-md">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="flex items-start">
              <div className="flex-shrink-0 mt-1">
                <Languages className="h-6 w-6 text-accent" />
              </div>
              <div className="ml-4">
                <h3 className="text-xl font-bold text-primary mb-2">Bilingual Expertise</h3>
                <p className="text-secondary">
                  Fluency in English & French – ideal for global collaboration and cross-cultural projects.
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="flex-shrink-0 mt-1">
                <Palette className="h-6 w-6 text-accent" />
              </div>
              <div className="ml-4">
                <h3 className="text-xl font-bold text-primary mb-2">Balanced Skill Set</h3>
                <p className="text-secondary">
                  Perfect balance of aesthetics and backend logic, combining the artistic with the technical.
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="flex-shrink-0 mt-1">
                <Globe className="h-6 w-6 text-accent" />
              </div>
              <div className="ml-4">
                <h3 className="text-xl font-bold text-primary mb-2">Global Experience</h3>
                <p className="text-secondary">
                  Experience across start-ups and cross-border teams, bringing diverse perspectives to every project.
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="flex-shrink-0 mt-1">
                <Award className="h-6 w-6 text-accent" />
              </div>
              <div className="ml-4">
                <h3 className="text-xl font-bold text-primary mb-2">Recognized Excellence</h3>
                <p className="text-secondary">
                  Award-winning performance in internships and volunteering that demonstrates commitment to quality.
                </p>
              </div>
            </div>
          </div>
        </div>
      </FadeIn>
    </section>
  );
}
