import { Card } from "@/components/ui/card";
import { ProjectType } from "@/lib/portfolio-data";

interface ProjectCardProps {
  project: ProjectType;
}

export default function ProjectCard({ project }: ProjectCardProps) {
  const { title, description, image, skills } = project;
  
  return (
    <Card className="card bg-white rounded-lg overflow-hidden shadow-md">
      <div className="h-48 bg-gray-200 relative overflow-hidden">
        <img 
          src={image.src} 
          alt={image.alt} 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-primary bg-opacity-30 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
          <span className="text-white font-medium px-4 py-2 rounded-md bg-primary bg-opacity-70">
            View Project
          </span>
        </div>
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-bold text-primary mb-3">{title}</h3>
        <ul className="list-disc list-inside text-secondary space-y-1 mb-4">
          {description.map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
        
        <div className="flex flex-wrap gap-2 mt-4">
          {skills.map((skill, index) => (
            <span key={index} className="px-3 py-1 bg-gray-100 text-secondary text-sm rounded-full">
              {skill}
            </span>
          ))}
        </div>
      </div>
    </Card>
  );
}
