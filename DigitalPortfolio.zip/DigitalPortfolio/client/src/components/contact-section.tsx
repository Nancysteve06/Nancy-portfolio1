import FadeIn from "@/components/fade-in";
import { Button } from "@/components/ui/button";
import { Mail, Linkedin, Download } from "lucide-react";
import resumePdf from "@/assets/resume.pdf";

export default function ContactSection() {
  return (
    <section id="contact">
      <FadeIn>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-semibold text-primary mb-2">Let's Connect</h2>
          <div className="section-divider mb-6"></div>
          <p className="text-accent max-w-2xl mx-auto">
            I'm open to freelance opportunities, collaborations, and connecting with like-minded professionals.
          </p>
        </div>
        
        <div className="bg-white p-8 rounded-lg shadow-md text-center">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <div className="flex flex-col items-center p-6 rounded-lg hover:bg-gray-50 transition-colors">
              <Mail className="h-10 w-10 text-accent mb-4" />
              <h3 className="text-xl font-bold text-primary mb-2">Email</h3>
              <a 
                href="mailto:Ballynallly@gmail.com" 
                className="text-accent hover:text-primary transition-colors"
              >
                Ballynallly@gmail.com
              </a>
            </div>
            
            <div className="flex flex-col items-center p-6 rounded-lg hover:bg-gray-50 transition-colors">
              <Linkedin className="h-10 w-10 text-accent mb-4" />
              <h3 className="text-xl font-bold text-primary mb-2">LinkedIn</h3>
              <a 
                href="https://www.linkedin.com/in/nancy-steve-913aa8351" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-accent hover:text-primary transition-colors"
              >
                Nancy Steve on LinkedIn
              </a>
            </div>
          </div>
          
          <p className="italic text-secondary mb-6">
            Remote opportunities welcome – freelance, part-time or full-time.
          </p>
          
          <Button asChild className="px-8 py-3 h-auto">
            <a href={resumePdf} download="Nancy_Steve_Resume.pdf">
              <Download className="mr-2 h-4 w-4" /> Download My Résumé
            </a>
          </Button>
        </div>
      </FadeIn>
    </section>
  );
}
